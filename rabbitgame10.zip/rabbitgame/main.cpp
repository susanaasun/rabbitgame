//
//  main.cpp
//  rabbitgame
//
//  Created by Susana Sun on 1/17/23.
//

// rabbits.cpp

//#include <iostream>
//#include <string>
//#include <random>
//#include <utility>
//#include <cstdlib>
//#include <cctype>
//#include "Game.h"
//using namespace std;
//
//
//
/////////////////////////////////////////////////////////////////////////////
//// main()
/////////////////////////////////////////////////////////////////////////////
//
//int main()
//{
//      // Create a game
//      // Use this instead to create a mini-game:   Game g(3, 5, 2);
//    Game g(10, 12, 20);
//
//      // Play the game
//    g.play();
//}

//test

    #include "History.h"
    #include "Arena.h"
    #include <iostream>
    using namespace std;

    int main()
    {
        Arena a(1, 3);
        a.history().record(1, 2);
        Arena a2(1, 2);
        a2.history().record(1, 1);
        a.history().display();
        cout << "===" << endl;
    }
