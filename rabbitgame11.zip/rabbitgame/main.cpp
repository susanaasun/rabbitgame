//
//  main.cpp
//  rabbitgame
//
//  Created by Susana Sun on 1/17/23.
//

// rabbits.cpp

//#include <iostream>
//#include <string>
//#include <random>
//#include <utility>
//#include <cstdlib>
//#include <cctype>
//#include "Game.h"
//using namespace std;
//
//
//
/////////////////////////////////////////////////////////////////////////////
//// main()
/////////////////////////////////////////////////////////////////////////////
//
//int main()
//{
//      // Create a game
//      // Use this instead to create a mini-game:   Game g(3, 5, 2);
//    Game g(10, 12, 20);
//
//      // Play the game
//    g.play();
//}

//test

#include "Arena.h"
    #include "Player.h"
    #include "History.h"
    #include "globals.h"
    #include <iostream>
    using namespace std;

    int main()
    {
        Arena a(1, 4);
        a.addPlayer(1, 2);
        a.player()->dropPoisonedCarrot();
        a.player()->dropPoisonedCarrot();
        a.player()->move(EAST);
        a.player()->dropPoisonedCarrot();
        a.player()->move(EAST);
        a.addRabbit(1, 1);
        while (a.rabbitCount() > 0)
            a.moveRabbits();
        a.player()->move(WEST);
        a.player()->dropPoisonedCarrot();
        a.history().display();
        cout << "====" << endl;
    }
